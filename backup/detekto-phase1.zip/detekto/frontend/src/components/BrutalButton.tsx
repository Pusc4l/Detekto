"use client";

import { motion, type HTMLMotionProps, type Variants } from "framer-motion";

export type ButtonTone = "acid" | "hazard" | "radar" | "magenta" | "crimson" | "canvas";

const TONES: Record<ButtonTone, string> = {
  acid: "bg-acid text-ink",
  hazard: "bg-hazard text-ink",
  radar: "bg-radar text-ink",
  magenta: "bg-magenta text-ink",
  crimson: "bg-crimson text-canvas",
  canvas: "bg-canvas text-ink",
};

/** Tombol fisik: hover menekan 4px (bayangan menyusut), tap menekan 8px (bayangan tertutup penuh). */
const PRESS: Variants = {
  rest: { x: 0, y: 0, boxShadow: "8px 8px 0px 0px #000000" },
  hover: { x: 4, y: 4, boxShadow: "4px 4px 0px 0px #000000" },
  tap: { x: 8, y: 8, boxShadow: "0px 0px 0px 0px #000000" },
};

type BrutalButtonProps = Omit<
  HTMLMotionProps<"button">,
  "variants" | "initial" | "animate" | "whileHover" | "whileTap" | "transition"
> & { tone?: ButtonTone };

export function BrutalButton({ tone = "acid", className = "", disabled, children, ...rest }: BrutalButtonProps) {
  return (
    <motion.button
      type="button"
      variants={PRESS}
      initial="rest"
      animate="rest"
      whileHover={disabled ? undefined : "hover"}
      whileTap={disabled ? undefined : "tap"}
      transition={{ type: "spring", stiffness: 900, damping: 40, mass: 0.6 }}
      disabled={disabled}
      className={`rounded-none border-4 border-ink px-6 py-3 font-display text-lg font-bold uppercase tracking-tight disabled:cursor-not-allowed disabled:bg-concrete disabled:text-ink ${TONES[tone]} ${className}`}
      {...rest}
    >
      {children}
    </motion.button>
  );
}
