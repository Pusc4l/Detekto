export type LogLevel = "SYS" | "INFO" | "OK" | "WARN" | "ERROR";
export type ServiceState = "primary" | "fallback" | "down";
export type WsState = "CONNECTING" | "OPEN" | "CLOSED";

export interface LogEvent {
  ts: string;
  level: LogLevel;
  source: string;
  message: string;
}

export interface ServiceStatus {
  key: string;
  label: string;
  state: ServiceState;
  mode: string;
  detail: string;
  latency_ms: number | null;
}

export interface HealthReport {
  status: "ok" | "degraded";
  app: string;
  version: string;
  timestamp: string;
  primary_count: number;
  fallback_count: number;
  down_count: number;
  services: ServiceStatus[];
}
