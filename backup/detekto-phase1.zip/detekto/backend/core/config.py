"""DETEKTO :: core/config.py
Konfigurasi terpusat + deteksi otomatis service (basis Auto-Fallback).
Semua nilai berasal dari environment / backend/.env. Tidak ada secret yang di-hardcode.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

_DEFAULT_ORIGINS = (
    "http://localhost:3000,http://127.0.0.1:3000,"
    "tauri://localhost,http://tauri.localhost,https://tauri.localhost"
)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "DETEKTO"
    app_version: str = "0.1.0"

    # --- Ephemeral vault / broker ---
    redis_url: str = "redis://127.0.0.1:6379/0"
    redis_ttl_seconds: int = Field(default=300, ge=1, le=3600)

    # --- Fact-finder ---
    searxng_url: str = "http://127.0.0.1:8080"

    # --- Graph ---
    memgraph_host: str = "127.0.0.1"
    memgraph_port: int = Field(default=7687, ge=1, le=65535)

    # --- Hive-Mind ---
    supabase_url: str = ""
    supabase_key: str = ""
    sqlite_path: str = "detekto_hive.db"

    # --- LLM ---
    groq_api_key: str = ""
    ollama_url: str = "http://127.0.0.1:11434"

    # --- Task queue ---
    celery_enabled: bool = False

    # --- Probing / CORS ---
    probe_timeout_seconds: float = Field(default=1.5, gt=0, le=10)
    cors_origins: str = _DEFAULT_ORIGINS

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def supabase_configured(self) -> bool:
        return bool(self.supabase_url.startswith("https://") and self.supabase_key)

    @property
    def sqlite_file(self) -> Path:
        p = Path(self.sqlite_path)
        return p if p.is_absolute() else BASE_DIR / p


@lru_cache
def get_settings() -> Settings:
    return Settings()
