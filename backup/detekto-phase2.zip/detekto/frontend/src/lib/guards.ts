import type { HealthReport, LogEvent, LogLevel, ServiceState, ServiceStatus } from "@/lib/types";

const LEVELS: readonly LogLevel[] = ["SYS", "INFO", "OK", "WARN", "ERROR"];
const STATES: readonly ServiceState[] = ["primary", "fallback", "down"];

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null;

export function isLogEvent(v: unknown): v is LogEvent {
  return (
    isRecord(v) &&
    typeof v.ts === "string" &&
    typeof v.source === "string" &&
    typeof v.message === "string" &&
    typeof v.level === "string" &&
    (LEVELS as readonly string[]).includes(v.level)
  );
}

function isServiceStatus(v: unknown): v is ServiceStatus {
  return (
    isRecord(v) &&
    typeof v.key === "string" &&
    typeof v.label === "string" &&
    typeof v.mode === "string" &&
    typeof v.detail === "string" &&
    typeof v.state === "string" &&
    (STATES as readonly string[]).includes(v.state) &&
    (v.latency_ms === null || typeof v.latency_ms === "number")
  );
}

export function isHealthReport(v: unknown): v is HealthReport {
  return (
    isRecord(v) &&
    (v.status === "ok" || v.status === "degraded") &&
    typeof v.app === "string" &&
    typeof v.version === "string" &&
    typeof v.timestamp === "string" &&
    typeof v.primary_count === "number" &&
    typeof v.fallback_count === "number" &&
    typeof v.down_count === "number" &&
    Array.isArray(v.services) &&
    v.services.every(isServiceStatus)
  );
}
