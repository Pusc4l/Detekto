export type LogLevel = "SYS" | "INFO" | "OK" | "WARN" | "ERROR";
export type ServiceState = "primary" | "fallback" | "down";
export type WsState = "CONNECTING" | "OPEN" | "CLOSED";

export interface LogEvent {
  ts: string;
  level: LogLevel;
  source: string;
  message: string;
}

export interface ServiceStatus {
  key: string;
  label: string;
  state: ServiceState;
  mode: string;
  detail: string;
  latency_ms: number | null;
}

export interface HealthReport {
  status: "ok" | "degraded";
  app: string;
  version: string;
  timestamp: string;
  primary_count: number;
  fallback_count: number;
  down_count: number;
  services: ServiceStatus[];
}

/* ------------------------- Fase 2: Interrogation Room ------------------------- */
export type Platform = "instagram" | "x" | "tiktok" | "facebook" | "youtube";
export type Stage = 1 | 2;
export type Bucket = "context" | "evidence";
export type NoticeTone = "error" | "warn" | "info";

export interface Notice {
  id: number;
  tone: NoticeTone;
  text: string;
}

/** Gambar yang sudah dikompresi (< 2MB) dan hidup HANYA di RAM browser. */
export interface CompressedImage {
  id: string;
  name: string;
  originalBytes: number;
  bytes: number;
  width: number;
  height: number;
  mime: "image/jpeg";
  /** Base64 murni (tanpa prefix data:) */
  base64: string;
  /** SHA-256 hex dari bytes terkompresi (kunci Smart Hashing di Fase 3) */
  sha256: string;
}

export interface PayloadImage {
  sha256: string;
  mime: "image/jpeg";
  bytes: number;
  width: number;
  height: number;
  base64: string;
}

export interface InterrogationPayload {
  context_text: string;
  context_images: PayloadImage[];
  platform: Platform;
  post_url: string | null;
  evidence_images: PayloadImage[];
}
