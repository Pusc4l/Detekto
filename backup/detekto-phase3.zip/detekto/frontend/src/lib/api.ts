import { API_BASE } from "@/lib/config";
import { isAnalysisResult, isUploadResponse } from "@/lib/guards";
import type { AnalysisResult, InterrogationPayload, UploadResponse } from "@/lib/types";

const UPLOAD_TIMEOUT_MS = 90_000;
const DEFAULT_TIMEOUT_MS = 15_000;

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null;

/** Ubah body error FastAPI ({detail:{code,message}} | {detail:[{loc,msg}]}) menjadi ApiError rapi. */
function toApiError(status: number, body: unknown): ApiError {
  if (isRecord(body)) {
    const detail = body.detail;
    if (isRecord(detail) && typeof detail.message === "string") {
      return new ApiError(status, typeof detail.code === "string" ? detail.code : "ERROR", detail.message);
    }
    if (Array.isArray(detail) && isRecord(detail[0])) {
      const first = detail[0];
      const loc = Array.isArray(first.loc) ? String(first.loc[first.loc.length - 1]) : "input";
      const msg = typeof first.msg === "string" ? first.msg : "tidak valid";
      return new ApiError(status, "VALIDATION", `INPUT DITOLAK SERVER (${loc.toUpperCase()}): ${msg}`.slice(0, 220));
    }
    if (typeof detail === "string") return new ApiError(status, "ERROR", detail.slice(0, 220));
  }
  return new ApiError(status, "HTTP", `SERVER MENJAWAB HTTP ${status}`);
}

async function request(path: string, init: RequestInit, timeoutMs: number): Promise<unknown> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, { ...init, cache: "no-store", signal: controller.signal });
  } catch (err) {
    const timedOut = err instanceof DOMException && err.name === "AbortError";
    throw new ApiError(
      0,
      timedOut ? "TIMEOUT" : "NETWORK",
      timedOut ? "BACKEND TIDAK MERESPON (TIMEOUT)" : "BACKEND TIDAK TERJANGKAU — PASTIKAN UVICORN BERJALAN DI PORT 8000",
    );
  } finally {
    window.clearTimeout(timer);
  }

  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (!res.ok) throw toApiError(res.status, body);
  return body;
}

export async function uploadEvidence(payload: InterrogationPayload): Promise<UploadResponse> {
  const body = await request(
    "/api/upload-evidence",
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) },
    UPLOAD_TIMEOUT_MS,
  );
  if (!isUploadResponse(body)) throw new ApiError(502, "SCHEMA", "RESPON UPLOAD TIDAK SESUAI SKEMA");
  return body;
}

export async function startAnalysis(sessionId: string): Promise<void> {
  await request(`/api/interrogate/${sessionId}/analyze`, { method: "POST" }, DEFAULT_TIMEOUT_MS);
}

export async function fetchResult(sessionId: string): Promise<AnalysisResult> {
  const body = await request(`/api/interrogate/${sessionId}/result`, { method: "GET" }, DEFAULT_TIMEOUT_MS);
  if (!isAnalysisResult(body)) throw new ApiError(502, "SCHEMA", "RESPON HASIL TIDAK SESUAI SKEMA");
  return body;
}

export async function purgeSession(sessionId: string): Promise<void> {
  await request(`/api/interrogate/${sessionId}`, { method: "DELETE" }, DEFAULT_TIMEOUT_MS);
}
