export type LogLevel = "SYS" | "INFO" | "OK" | "WARN" | "ERROR";
export type ServiceState = "primary" | "fallback" | "down";
export type WsState = "CONNECTING" | "OPEN" | "CLOSED";

export interface LogEvent {
  ts: string;
  level: LogLevel;
  source: string;
  message: string;
}

export interface ServiceStatus {
  key: string;
  label: string;
  state: ServiceState;
  mode: string;
  detail: string;
  latency_ms: number | null;
}

export interface HealthReport {
  status: "ok" | "degraded";
  app: string;
  version: string;
  timestamp: string;
  primary_count: number;
  fallback_count: number;
  down_count: number;
  services: ServiceStatus[];
}

/* ------------------------- Fase 2: Interrogation Room ------------------------- */
export type Platform = "instagram" | "x" | "tiktok" | "facebook" | "youtube";
export type Stage = 1 | 2;
export type Bucket = "context" | "evidence";
export type NoticeTone = "error" | "warn" | "info";

export interface Notice {
  id: number;
  tone: NoticeTone;
  text: string;
}

/** Gambar yang sudah dikompresi (< 2MB) dan hidup HANYA di RAM browser. */
export interface CompressedImage {
  id: string;
  name: string;
  originalBytes: number;
  bytes: number;
  width: number;
  height: number;
  mime: "image/jpeg";
  /** Base64 murni (tanpa prefix data:) */
  base64: string;
  /** SHA-256 hex dari bytes terkompresi (kunci Smart Hashing di Fase 3) */
  sha256: string;
}

export interface PayloadImage {
  sha256: string;
  mime: "image/jpeg";
  bytes: number;
  width: number;
  height: number;
  base64: string;
}

export interface InterrogationPayload {
  context_text: string;
  context_images: PayloadImage[];
  platform: Platform;
  post_url: string | null;
  evidence_images: PayloadImage[];
}

/* ------------------------- Fase 3: Ingestion, OCR & Ground Truth ------------------------- */
export type AnalysisStatus = "queued" | "running" | "done" | "error";
export type Confidence = "low" | "medium" | "high";
export type RunStatus = "idle" | "uploading" | "analyzing" | "done" | "error";

export interface UploadResponse {
  session_id: string;
  ttl_seconds: number;
  vault_backend: "redis" | "memory";
  accepted_context: number;
  accepted_evidence: number;
  total_bytes: number;
}

export interface TargetComment {
  text: string;
  likes: number;
  image_index: number;
  injection_flag: boolean;
}

export interface TargetEntity {
  username: string;
  comment_count: number;
  total_likes: number;
  image_indexes: number[];
  injection_flag: boolean;
  comments: TargetComment[];
}

export interface GroundTruthSource {
  title: string;
  url: string;
  snippet: string;
  engine: "searxng" | "duckduckgo";
  credible: boolean;
}

export interface GroundTruthContext {
  main_claim: string;
  objective_summary: string;
  neutral_baseline: string;
  dorking_keywords: string[];
  sources: GroundTruthSource[];
  confidence: Confidence;
  evidence_grounded: boolean;
  reasoning_engine: string;
  search_engine: string;
  injection_flags: string[];
}

export interface AnalysisResult {
  session_id: string;
  status: AnalysisStatus;
  started_at: string;
  finished_at: string | null;
  ocr_engine: string | null;
  context_image_count: number;
  evidence_image_count: number;
  targets: TargetEntity[];
  ground_truth: GroundTruthContext | null;
  warnings: string[];
  error: string | null;
  media_purged: boolean;
}

export interface RunState {
  status: RunStatus;
  sessionId: string | null;
  vaultBackend: "redis" | "memory" | null;
  result: AnalysisResult | null;
  error: string | null;
}
