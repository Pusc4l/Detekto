import { create } from "zustand";
import {
  CompressionError,
  MAX_IMAGES_PER_BUCKET,
  compressImage,
  runPool,
} from "@/utils/imageCompressor";
import { ApiError, fetchResult, purgeSession, startAnalysis, uploadEvidence } from "@/lib/api";
import { MAX_CONTEXT_CHARS, sanitizeText, validatePostUrl } from "@/lib/sanitize";
import { useSystemStore } from "@/store/useSystemStore";
import type {
  Bucket,
  CompressedImage,
  InterrogationPayload,
  Notice,
  NoticeTone,
  PayloadImage,
  Platform,
  RunState,
  Stage,
} from "@/lib/types";

const COMPRESSION_CONCURRENCY = 2;
const MAX_NOTICES = 5;
const MIN_CONTEXT_CHARS = 10;

const POLL_INTERVAL_MS = 1500;
const POLL_TIMEOUT_MS = 180_000;

const IDLE_RUN: RunState = { status: "idle", sessionId: null, vaultBackend: null, result: null, error: null };

let noticeSeq = 0;
let runToken = 0; // membatalkan polling lama bila pengguna reset / memulai ulang

const sleep = (ms: number): Promise<void> => new Promise((resolve) => window.setTimeout(resolve, ms));

interface InterrogationState {
  stage: Stage;
  contextText: string;
  contextImages: CompressedImage[];
  evidenceImages: CompressedImage[];
  pending: Record<Bucket, number>;
  platform: Platform | "";
  postUrl: string;
  notices: Notice[];
  run: RunState;

  setStage: (stage: Stage) => void;
  setContextText: (text: string) => void;
  setPlatform: (platform: Platform | "") => void;
  setPostUrl: (url: string) => void;
  addFiles: (bucket: Bucket, files: FileList | File[]) => Promise<void>;
  removeImage: (bucket: Bucket, id: string) => void;
  clearBucket: (bucket: Bucket) => void;
  notify: (tone: NoticeTone, text: string) => void;
  dismissNotice: (id: number) => void;
  buildPayload: () => InterrogationPayload | null;
  runInterrogation: () => Promise<void>;
  reset: () => void;
}

const toPayloadImage = (img: CompressedImage): PayloadImage => ({
  sha256: img.sha256,
  mime: img.mime,
  bytes: img.bytes,
  width: img.width,
  height: img.height,
  base64: img.base64,
});

function describeError(err: unknown, fileName: string): string {
  const name = fileName.slice(0, 28).toUpperCase();
  if (err instanceof CompressionError) return `${name}: ${err.message}`;
  return `${name}: KEGAGALAN TIDAK TERDUGA SAAT KOMPRESI`;
}

const initialState = {
  stage: 1 as Stage,
  contextText: "",
  contextImages: [] as CompressedImage[],
  evidenceImages: [] as CompressedImage[],
  pending: { context: 0, evidence: 0 } as Record<Bucket, number>,
  platform: "" as Platform | "",
  postUrl: "",
  notices: [] as Notice[],
  run: IDLE_RUN,
};

export const useInterrogationStore = create<InterrogationState>((set, get) => ({
  ...initialState,

  setStage: (stage) => set({ stage }),

  setContextText: (text) => set({ contextText: sanitizeText(text, MAX_CONTEXT_CHARS) }),

  setPlatform: (platform) => set({ platform }),

  setPostUrl: (url) => set({ postUrl: url.slice(0, 400) }),

  notify: (tone, text) =>
    set((s) => ({ notices: [...s.notices, { id: ++noticeSeq, tone, text }].slice(-MAX_NOTICES) })),

  dismissNotice: (id) => set((s) => ({ notices: s.notices.filter((n) => n.id !== id) })),

  addFiles: async (bucket, files) => {
    const list = Array.from(files);
    if (list.length === 0) return;

    const state = get();
    const current = bucket === "context" ? state.contextImages.length : state.evidenceImages.length;
    const free = Math.max(0, MAX_IMAGES_PER_BUCKET - current - state.pending[bucket]);
    const accepted = list.slice(0, free);
    const rejected = list.length - accepted.length;

    if (rejected > 0) {
      get().notify(
        "error",
        `KUOTA ${MAX_IMAGES_PER_BUCKET}/${MAX_IMAGES_PER_BUCKET} PENUH — ${rejected} FILE DITOLAK OTOMATIS`,
      );
    }
    if (accepted.length === 0) return;

    // Reservasi slot SEBELUM kompresi dimulai -> unggahan beruntun tidak bisa menyalip kuota (anti race condition).
    set((s) => ({ pending: { ...s.pending, [bucket]: s.pending[bucket] + accepted.length } }));

    await runPool(accepted, COMPRESSION_CONCURRENCY, async (file) => {
      let image: CompressedImage | null = null;
      let failure: string | null = null;
      try {
        image = await compressImage(file);
      } catch (err) {
        failure = describeError(err, file.name);
      }

      let duplicate = false;
      set((s) => {
        const pending = { ...s.pending, [bucket]: Math.max(0, s.pending[bucket] - 1) };
        if (!image) return { pending };
        const list = bucket === "context" ? s.contextImages : s.evidenceImages;
        if (list.some((i) => i.sha256 === image?.sha256)) {
          duplicate = true;
          return { pending };
        }
        const next = [...list, image];
        return bucket === "context" ? { pending, contextImages: next } : { pending, evidenceImages: next };
      });

      if (failure) get().notify("error", failure);
      else if (duplicate) get().notify("warn", `${file.name.slice(0, 28).toUpperCase()}: DUPLIKAT — DITOLAK`);
    });
  },

  removeImage: (bucket, id) =>
    set((s) =>
      bucket === "context"
        ? { contextImages: s.contextImages.filter((i) => i.id !== id) }
        : { evidenceImages: s.evidenceImages.filter((i) => i.id !== id) },
    ),

  clearBucket: (bucket) => set(bucket === "context" ? { contextImages: [] } : { evidenceImages: [] }),

  buildPayload: () => {
    const s = get();
    const url = validatePostUrl(s.postUrl, s.platform);
    if (s.platform === "" || !url.ok || s.evidenceImages.length === 0) return null;
    return {
      context_text: sanitizeText(s.contextText, MAX_CONTEXT_CHARS).trim(),
      context_images: s.contextImages.map(toPayloadImage),
      platform: s.platform,
      post_url: url.value,
      evidence_images: s.evidenceImages.map(toPayloadImage),
    };
  },

  runInterrogation: async () => {
    const current = get().run.status;
    if (current === "uploading" || current === "analyzing") return;

    const payload = get().buildPayload();
    if (!payload) {
      get().notify("error", "PAYLOAD BELUM LENGKAP — PILIH PLATFORM, URL VALID, & UNGGAH MINIMAL 1 BUKTI");
      return;
    }

    const token = ++runToken;
    const sys = useSystemStore.getState();
    const imageCount = payload.context_images.length + payload.evidence_images.length;
    set({ run: { ...IDLE_RUN, status: "uploading" } });
    sys.pushLocalLog("SYS", "UPLOAD", `MENGIRIM ${imageCount} GAMBAR (BASE64) KE VAULT RAM LOKAL...`);

    try {
      const upload = await uploadEvidence(payload);
      if (token !== runToken) return;
      set({ run: { ...IDLE_RUN, status: "analyzing", sessionId: upload.session_id, vaultBackend: upload.vault_backend } });
      sys.pushLocalLog(
        "OK",
        "UPLOAD",
        `SESI ${upload.session_id.slice(0, 8).toUpperCase()} DITERIMA // ${upload.vault_backend.toUpperCase()} // TTL ${upload.ttl_seconds}s`,
      );

      await startAnalysis(upload.session_id);
      const deadline = Date.now() + POLL_TIMEOUT_MS;
      for (;;) {
        await sleep(POLL_INTERVAL_MS);
        if (token !== runToken) return;
        const result = await fetchResult(upload.session_id);
        if (token !== runToken) return;

        if (result.status === "done") {
          // Server sudah menghancurkan buffer gambar; kosongkan juga RAM browser (Zero-Bloat dua sisi).
          set({
            run: { status: "done", sessionId: upload.session_id, vaultBackend: upload.vault_backend, result, error: null },
            contextImages: [],
            evidenceImages: [],
          });
          get().notify("info", `ANALISIS SELESAI: ${result.targets.length} TARGET TERDETEKSI. RAM BROWSER DIKOSONGKAN.`);
          return;
        }
        if (result.status === "error") {
          const message = result.error ?? "ANALISIS GAGAL";
          set({
            run: { status: "error", sessionId: upload.session_id, vaultBackend: upload.vault_backend, result, error: message },
          });
          get().notify("error", message.slice(0, 220));
          return;
        }
        set((s) => ({ run: { ...s.run, result } }));
        if (Date.now() > deadline) throw new ApiError(0, "TIMEOUT", "ANALISIS MELEBIHI BATAS WAKTU 3 MENIT");
      }
    } catch (err) {
      if (token !== runToken) return;
      const message = err instanceof ApiError ? err.message : "KEGAGALAN TAK TERDUGA SAAT MENGIRIM BUKTI";
      set((s) => ({ run: { ...s.run, status: "error", error: message } }));
      get().notify("error", message.slice(0, 220));
      sys.pushLocalLog("ERROR", "UPLOAD", message.slice(0, 160));
    }
  },

  // Membuang referensi semua string Base64 -> GC browser bebas membersihkan RAM. Sesi server ikut dihapus.
  reset: () => {
    const sessionId = get().run.sessionId;
    runToken += 1;
    if (sessionId) void purgeSession(sessionId).catch(() => undefined);
    set({ ...initialState, notices: get().notices });
  },
}));

/* ------------------------------- selector murni ------------------------------- */
type Snapshot = Pick<
  InterrogationState,
  "contextText" | "contextImages" | "evidenceImages" | "pending" | "platform" | "postUrl"
>;

export const canLockContext = (s: Snapshot): boolean =>
  s.pending.context === 0 &&
  (s.contextText.trim().length >= MIN_CONTEXT_CHARS || s.contextImages.length > 0);

export const isRunBusy = (s: Pick<InterrogationState, "run">): boolean =>
  s.run.status === "uploading" || s.run.status === "analyzing";

export const canExecute = (s: Snapshot): boolean =>
  s.pending.evidence === 0 &&
  s.pending.context === 0 &&
  s.evidenceImages.length > 0 &&
  s.platform !== "" &&
  validatePostUrl(s.postUrl, s.platform).ok;

export const MIN_CONTEXT_LENGTH = MIN_CONTEXT_CHARS;
