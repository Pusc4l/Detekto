-- DETEKTO :: Fase 5 — jalankan SEKALI di Supabase SQL Editor (opsional; tanpa ini sistem memakai SQLite lokal).
-- Bobot disimpan per-instance (instance_id) agar bobot satu pengguna tidak menimpa pengguna lain.
create table if not exists public.ml_model_state (
    instance_id text primary key,
    version     integer      not null,
    n_samples   integer      not null,
    payload     jsonb        not null,
    updated_at  timestamptz  not null default now()
);
alter table public.ml_model_state enable row level security;
-- Gunakan SERVICE ROLE key lokal di backend/.env (SUPABASE_KEY) HANYA di perangkat Anda sendiri. Jangan pernah menaruhnya di frontend.
